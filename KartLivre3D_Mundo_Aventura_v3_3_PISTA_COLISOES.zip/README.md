# Kart Livre 3D — Mundo Aventura v3.2

Projeto Godot 4 (GDScript 2.0) baseado no projeto original recebido. A cena principal continua sendo gerada proceduralmente por `main.gd`, e o modelo GLB original do kart foi preservado.

## Melhorias desta revisão
- Malha de pista fechada com 320 amostras, asfalto, acostamento e bordas.
- Colisão estática da pista e do terreno mantida.
- Colisores físicos adicionados às barreiras laterais, rampas, troncos e rochas.
- Kart com aderência lateral, frenagem/reversão, gravidade, aderência ao solo e resposta de impacto.
- Controles na tela feitos com botões nativos, posicionados por âncoras relativas à tela. A ação permanece ativa enquanto o botão estiver pressionado.
- Nitro por botão/tecla e pads de impulso mantidos; rampas acionam saltos controlados.
- Cenário revisado: montanhas facetadas, morros em camadas, árvores distribuídas junto às margens do circuito, arbustos, rochas e flores para reduzir grandes áreas verdes vazias.
- Vegetação e pedras posicionadas usando a tangente e a lateral da pista, evitando a distribuição circular que deixava áreas vazias e objetos mal alinhados.
- Malhas de cenário simplificadas para reduzir custo de renderização em Android.
- Renderizador Compatibility mantido para favorecer compatibilidade com Android.

## Como importar
1. Extraia o ZIP.
2. Abra o Godot 4.3 ou uma versão 4.x compatível.
3. Selecione **Importar** e escolha `project.godot`.
4. Aguarde a importação do GLB e execute `Main.tscn`.

## Controles
- W / seta para cima: acelerar
- S / seta para baixo: frear e, parado, engatar ré
- A / D ou setas laterais: virar
- Shift / botão NITRO: nitro
- Botões na tela: mantenha pressionado para continuar acionando
- Pads ciano: impulso ao passar sobre eles
- Rampas: salto acionado automaticamente ao alcançar a zona da rampa

## Estado dos testes
A estrutura do ZIP e os conteúdos dos arquivos foram inspecionados. Foram feitas verificações estáticas e conferência da estrutura do projeto. **Não foi possível executar o Godot nesta sessão**, pois o executável do Godot não está disponível no ambiente. Portanto, não afirmo que a cena foi executada nem que colisões, controles táteis ou desempenho foram testados em aparelho Android.

Antes de publicar, teste no Godot e em um tablet real: aderência nas curvas, colisão nas emendas da pista, comportamento nas duas rampas, rotação/orientação do GLB, escalas dos botões e desempenho com sombras habilitadas.


## Controles táteis híbridos (Android)

- Joystick analógico virtual no canto inferior esquerdo: arraste horizontalmente para dirigir; a direção é proporcional ao deslocamento e retorna ao centro ao soltar.
- Acelerador grande no canto inferior direito: mantenha pressionado para acelerar.
- Freio e nitro em botões separados: mantenha pressionado para acionar.
- O script `touch_controls.gd` processa IDs de toque independentes para permitir direção e ações simultâneas (multitoque).
- No computador, os controles de teclado existentes continuam disponíveis.

A interface foi dimensionada em relação ao tamanho do viewport para acompanhar diferentes resoluções e tablets em orientação paisagem. A validação final de multitoque e posicionamento deve ser feita em dispositivo Android e no Godot 4.


## Revisão 3.3 — pista e colisões
- A pista foi reconstruída com segmentos curtos de asfalto e colisores físicos correspondentes.
- O terreno-base agora tem uma superfície de colisão em Y=0 para impedir quedas infinitas.
- As elevações do circuito foram suavizadas e as rampas reduzidas para evitar grandes blocos suspensos.
- O projeto ainda precisa ser executado no Godot 4 para validar visual, física e desempenho no dispositivo Android.
