extends CharacterBody3D

@export var acceleration: float = 22.0
@export var reverse_speed: float = 7.0
@export var max_speed: float = 27.0
@export var steering_speed: float = 2.15
@export var drag: float = 5.5
@export var lateral_grip: float = 8.0
@export var gravity_strength: float = 24.0
@export var jump_impulse: float = 8.5

var current_speed: float = 0.0
var _air_control: float = 0.35

func _ready() -> void:
    floor_snap_length = 0.45
    floor_max_angle = deg_to_rad(52.0)
    safe_margin = 0.04
    motion_mode = CharacterBody3D.MOTION_MODE_GROUNDED
    collision_layer = 1
    collision_mask = 1
    _add_default_actions()

func _physics_process(delta: float) -> void:
    var throttle := _axis_strength("accelerate", "ui_up")
    var brake := _axis_strength("brake", "ui_down")
    var left := _axis_strength("steer_left", "ui_left")
    var right := _axis_strength("steer_right", "ui_right")

    if throttle > 0.01:
        current_speed = move_toward(current_speed, max_speed, acceleration * throttle * delta)
    elif brake > 0.01:
        if current_speed > 0.8:
            current_speed = move_toward(current_speed, 0.0, acceleration * 1.9 * brake * delta)
        else:
            current_speed = move_toward(current_speed, -reverse_speed, acceleration * 0.65 * brake * delta)
    else:
        current_speed = move_toward(current_speed, 0.0, drag * delta)

    var steering := right - left
    var speed_factor := clampf(absf(current_speed) / 7.0, 0.18, 1.0)
    if absf(current_speed) > 0.25:
        rotation.y -= steering * steering_speed * speed_factor * signf(current_speed) * delta

    var forward := -global_transform.basis.z
    var desired_horizontal := forward * current_speed
    var grip := lateral_grip if is_on_floor() else lateral_grip * _air_control
    velocity.x = move_toward(velocity.x, desired_horizontal.x, grip * delta + absf(current_speed) * 0.35 * delta)
    velocity.z = move_toward(velocity.z, desired_horizontal.z, grip * delta + absf(current_speed) * 0.35 * delta)

    if not is_on_floor():
        velocity.y -= gravity_strength * delta
    elif velocity.y < 0.0:
        velocity.y = -0.8

    move_and_slide()

    # Reduz a velocidade longitudinal ao bater em uma barreira ou obstáculo.
    if get_slide_collision_count() > 0:
        var collision := get_last_slide_collision()
        if collision:
            var normal := collision.get_normal()
            if absf(normal.y) < 0.65:
                current_speed *= 0.72

func _axis_strength(primary: String, secondary: String) -> float:
    return minf(1.0, Input.get_action_strength(primary) + Input.get_action_strength(secondary))

func launch(impulse: float = 8.5) -> void:
    if is_on_floor():
        velocity.y = impulse

func _add_default_actions() -> void:
    _ensure_action("accelerate", KEY_W)
    _ensure_action("brake", KEY_S)
    _ensure_action("steer_left", KEY_A)
    _ensure_action("steer_right", KEY_D)
    _ensure_action("nitro", KEY_SHIFT)

func _ensure_action(action_name: String, keycode: Key) -> void:
    if not InputMap.has_action(action_name):
        InputMap.add_action(action_name)
    if InputMap.action_get_events(action_name).is_empty():
        var event := InputEventKey.new()
        event.physical_keycode = keycode
        InputMap.action_add_event(action_name, event)
