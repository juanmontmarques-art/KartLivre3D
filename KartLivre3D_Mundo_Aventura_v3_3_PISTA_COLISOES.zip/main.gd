extends Node3D

# Kart Livre 3D — Mundo Aventura v3
# Pista procedural sinuosa, elevações, rampas, nitro e cenário estilizado.

var kart: CharacterBody3D
var camera: Camera3D
var speed_label: Label
var timer_label: Label
var nitro_label: Label
var elapsed := 0.0
var started := false
var nitro_cooldown := 0.0
var nitro_active_time := 0.0
var boost_cooldown := 0.0
var jump_cooldown := 0.0
var jump_points: Array[Vector3] = []
var boost_pads: Array[Vector3] = []
var track_points: Array[Vector3] = []
var track_samples := 420
var track_width := 10.0

func _ready() -> void:
    _make_world()
    _make_landscape()
    _make_track()
    _make_kart()
    _make_camera()
    _make_ui()

func _process(delta: float) -> void:
    if started:
        elapsed += delta
    nitro_cooldown = maxf(0.0, nitro_cooldown - delta)
    if nitro_active_time > 0.0:
        nitro_active_time = maxf(0.0, nitro_active_time - delta)
        if nitro_active_time <= 0.0 and is_instance_valid(kart):
            kart.max_speed = 25.0
    boost_cooldown = maxf(0.0, boost_cooldown - delta)
    jump_cooldown = maxf(0.0, jump_cooldown - delta)
    if is_instance_valid(kart):
        if Input.is_action_pressed("nitro") and nitro_cooldown <= 0.0:
            kart.max_speed = 39.0
            kart.current_speed = minf(39.0, maxf(kart.current_speed, 0.0) + 12.0)
            nitro_active_time = 1.5
            nitro_cooldown = 3.2
        if jump_cooldown <= 0.0 and kart.is_on_floor():
            for jump_point in jump_points:
                if kart.global_position.distance_to(jump_point) < 3.4:
                    kart.launch(8.5)
                    jump_cooldown = 1.8
                    break
        if boost_cooldown <= 0.0:
            for pad in boost_pads:
                if kart.global_position.distance_to(pad) < 3.8:
                    kart.current_speed = minf(kart.max_speed + 10.0, maxf(kart.current_speed, 0.0) + 8.0)
                    boost_cooldown = 1.2
                    break
        if is_instance_valid(speed_label):
            speed_label.text = "VELOCIDADE  %d km/h" % int(absf(kart.current_speed) * 3.6)
        if absf(kart.current_speed) > 0.5:
            started = true
    if is_instance_valid(timer_label):
        timer_label.text = "TEMPO  %05.1f" % elapsed
    if is_instance_valid(nitro_label):
        nitro_label.text = "NITRO  PRONTO" if nitro_cooldown <= 0.0 else ("NITRO  ATIVO!" if nitro_active_time > 0.0 else "NITRO  RECARREGANDO")

func _mat(color: Color, roughness: float = 0.82, metallic: float = 0.0, emission: Color = Color.BLACK) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    material.metallic = metallic
    if emission != Color.BLACK:
        material.emission_enabled = true
        material.emission = emission
        material.emission_energy_multiplier = 1.5
    return material

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, node_name: String = "Prop", roughness: float = 0.82, emission: Color = Color.BLACK) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color, roughness, 0.0, emission)
    node.name = node_name
    parent.add_child(node)
    return node

func _solid_box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, node_name: String, bevel: float = 0.0) -> MeshInstance3D:
    var visual := _box(parent, size, pos, color, node_name, 0.78)
    var body := StaticBody3D.new()
    body.name = node_name + "Collision_" + str(visual.get_instance_id())
    body.position = pos
    body.rotation = visual.rotation
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    parent.add_child(body)
    return visual

func _sphere(parent: Node3D, radius: float, pos: Vector3, color: Color, node_name: String = "Sphere", height: float = -1.0) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = height if height > 0.0 else radius * 2.0
    mesh.radial_segments = 9
    mesh.rings = 5
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    node.name = node_name
    parent.add_child(node)
    return node

func _cylinder(parent: Node3D, radius: float, height: float, pos: Vector3, color: Color, node_name: String = "Cylinder", radial_segments: int = 10) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = radial_segments
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color, 0.8)
    node.name = node_name
    parent.add_child(node)
    return node

func _make_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.055, 0.24, 0.48)
    sky_mat.sky_horizon_color = Color(0.72, 0.86, 0.96)
    sky_mat.ground_bottom_color = Color(0.12, 0.22, 0.16)
    sky_mat.ground_horizon_color = Color(0.53, 0.66, 0.53)
    sky_mat.sun_angle_max = 24.0
    sky.sky_material = sky_mat
    environment.sky = sky
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.78, 0.86, 1.0)
    environment.ambient_light_energy = 0.8
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.tonemap_exposure = 1.08
    env.environment = environment
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.name = "SolQuente"
    sun.rotation_degrees = Vector3(-47, -25, 0)
    sun.light_color = Color(1.0, 0.88, 0.70)
    sun.light_energy = 1.05
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 75.0
    add_child(sun)

func _track_point(t: float) -> Vector3:
    var x := 33.0 * sin(t) + 5.5 * sin(2.0 * t) + 2.0 * sin(3.0 * t)
    var z := 27.0 * cos(t) + 4.5 * sin(3.0 * t)
    # Grandes ondulações: subida panorâmica, descida rápida e um salto elevado.
    var y := 1.6 + 1.2 * sin(2.0 * t + 0.4) + 1.15 * pow(maxf(0.0, sin(t - 0.65)), 8.0)
    y += 1.55 * pow(maxf(0.0, sin(t - 2.6)), 10.0)
    return Vector3(x, y, z)

func _track_tangent(t: float) -> Vector3:
    var a := _track_point(t - 0.01)
    var b := _track_point(t + 0.01)
    return (b - a).normalized()

func _ribbon_mesh(parent: Node3D, width: float, y_offset: float, material: Material, node_name: String) -> MeshInstance3D:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(track_samples):
        var t0 := TAU * float(i) / float(track_samples)
        var t1 := TAU * float(i + 1) / float(track_samples)
        var p0 := _track_point(t0)
        var p1 := _track_point(t1)
        var side0 := _track_tangent(t0).cross(Vector3.UP).normalized()
        var side1 := _track_tangent(t1).cross(Vector3.UP).normalized()
        var l0 := p0 - side0 * width * 0.5 + Vector3.UP * y_offset
        var r0 := p0 + side0 * width * 0.5 + Vector3.UP * y_offset
        var l1 := p1 - side1 * width * 0.5 + Vector3.UP * y_offset
        var r1 := p1 + side1 * width * 0.5 + Vector3.UP * y_offset
        st.set_color(Color.WHITE)
        st.add_vertex(l0); st.add_vertex(r0); st.add_vertex(l1)
        st.add_vertex(r0); st.add_vertex(r1); st.add_vertex(l1)
    st.generate_normals()
    var mesh := st.commit()
    var node := MeshInstance3D.new()
    node.name = node_name
    node.mesh = mesh
    node.material_override = material
    parent.add_child(node)
    return node

func _make_track() -> void:
    # Terreno e colisão de base para a área fora da pista.
    _box(self, Vector3(240, 1.0, 220), Vector3(0, -1.05, 0), Color(0.24, 0.38, 0.20), "IlhaVerde")
    var ground_body := StaticBody3D.new()
    ground_body.name = "ColisaoTerreno"
    ground_body.collision_layer = 1
    ground_body.collision_mask = 1
    ground_body.position = Vector3(0, -1.05, 0)
    var ground_col := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(240, 1.0, 220)
    ground_col.shape = ground_shape
    ground_body.add_child(ground_col)
    add_child(ground_body)

    # Faixa de escape, acostamento e asfalto seguem a mesma curva 3D.
    _ribbon_mesh(self, track_width + 5.0, -0.08, _mat(Color(0.86, 0.76, 0.49)), "AcostamentoAreia")
    _ribbon_mesh(self, track_width + 2.0, 0.00, _mat(Color(0.89, 0.20, 0.13)), "BordasVermelhas")
    var road := _ribbon_mesh(self, track_width, 0.08, _mat(Color(0.105, 0.13, 0.17), 0.96), "PistaAsfalto")
    var road_body := StaticBody3D.new()
    road_body.name = "ColisaoPista"
    road_body.collision_layer = 1
    road_body.collision_mask = 1
    var road_col := CollisionShape3D.new()
    road_col.shape = road.mesh.create_trimesh_shape()
    road_body.add_child(road_col)
    add_child(road_body)

    # Zebras segmentadas ao longo das curvas.
    for i in range(0, track_samples, 3):
        var t := TAU * float(i) / float(track_samples)
        var p := _track_point(t)
        var tangent := _track_tangent(t)
        var side := tangent.cross(Vector3.UP).normalized()
        var color := Color(0.96, 0.94, 0.85) if (i / 3) % 2 == 0 else Color(0.92, 0.18, 0.14)
        for sign_side in [-1.0, 1.0]:
            var curb := _box(self, Vector3(1.25, 0.13, 1.15), p + side * sign_side * (track_width * 0.5 + 0.55) + Vector3.UP * 0.10, color, "ZebraCurva")
            curb.look_at(curb.global_position + tangent, Vector3.UP)
        if i % 12 == 0:
            var dash := _box(self, Vector3(0.18, 0.035, 1.65), p + Vector3.UP * 0.19, Color(0.83, 0.88, 0.87), "FaixaCentral", 0.9)
            dash.look_at(dash.global_position + tangent, Vector3.UP)

    # Linha de largada posicionada perto do início da volta.
    var start_t := PI * 0.5
    var start_p := _track_point(start_t) + Vector3.UP * 0.20
    var start_tangent := _track_tangent(start_t)
    var start_yaw := atan2(-start_tangent.x, -start_tangent.z)
    for x_i in range(10):
        for z_i in range(2):
            var tile_color := Color(0.95, 0.95, 0.91) if (x_i + z_i) % 2 == 0 else Color(0.08, 0.09, 0.11)
            var tile := _box(self, Vector3(0.9, 0.045, 0.65), start_p + Vector3(float(x_i - 5) * 0.9, 0.0, 0.0) + Vector3(0, 0, float(z_i - 1) * 0.65), tile_color, "GridLargada")
            tile.rotation.y = start_yaw

    # Rampas visuais, boost pads e placas de nitro colocados sobre a pista.
    _make_ramp(0.72, "RampaCanyon", Color(0.97, 0.48, 0.10))
    _make_ramp(3.62, "RampaCosta", Color(0.12, 0.82, 0.94))
    for t in [1.20, 2.85, 4.55, 5.55]:
        var p := _track_point(t) + Vector3.UP * 0.24
        var tangent := _track_tangent(t)
        var pad := _box(self, Vector3(5.4, 0.16, 2.0), p, Color(0.08, 0.78, 0.95), "BoostNitro", 0.25, Color(0.02, 0.65, 1.0))
        pad.look_at(pad.global_position + tangent, Vector3.UP)
        for j in range(3):
            var stripe := _box(self, Vector3(0.20, 0.04, 1.55), p + Vector3.UP * 0.11 + Vector3((j - 1) * 1.25, 0.0, 0.0), Color(0.96, 1.0, 0.72), "FaixaBoost", 0.2, Color(0.65, 1.0, 0.75))
            stripe.look_at(stripe.global_position + tangent, Vector3.UP)
        boost_pads.append(p)

    # Barreiras de segurança coloridas em trechos de maior velocidade.
    for t in [0.25, 0.42, 1.48, 2.10, 3.25, 4.10, 5.15, 5.82]:
        var p := _track_point(t)
        var tangent := _track_tangent(t)
        var side := tangent.cross(Vector3.UP).normalized()
        for s in [-1.0, 1.0]:
            var rail := _solid_box(self, Vector3(0.42, 0.82, 5.2), p + side * s * (track_width * 0.5 + 2.1) + Vector3.UP * 0.62, Color(0.96, 0.88, 0.70), "GuardRail")
            rail.look_at(rail.global_position + tangent, Vector3.UP)
            var rail_body := get_node_or_null("GuardRailCollision_" + str(rail.get_instance_id()))
            if rail_body:
                rail_body.rotation = rail.rotation

func _make_ramp(t: float, ramp_name: String, color: Color) -> void:
    var p := _track_point(t)
    jump_points.append(p + Vector3.UP * 0.35)
    var tangent := _track_tangent(t)
    var ramp := _solid_box(self, Vector3(7.0, 0.32, 5.5), p + Vector3.UP * 0.22, color, ramp_name, 0.55)
    ramp.look_at(ramp.global_position + tangent, Vector3.UP)
    ramp.rotation.x = -0.13
    var ramp_body := get_node_or_null(ramp_name + "Collision_" + str(ramp.get_instance_id()))
    if ramp_body:
        ramp_body.rotation = ramp.rotation
    _box(self, Vector3(5.2, 0.10, 0.28), p + Vector3.UP * 0.45, Color(1.0, 0.92, 0.55), "FaixaRampa", 0.3, Color(1.0, 0.45, 0.08))

func _make_landscape() -> void:
    # Paisagem em camadas: montanhas facetadas ao fundo, morros e vegetação
    # posicionados em relação à pista (em vez de espalhados aleatoriamente).
    var mountain_colors := [
        Color(0.20, 0.34, 0.39), Color(0.25, 0.41, 0.43),
        Color(0.31, 0.47, 0.43), Color(0.39, 0.53, 0.43)
    ]
    for i in range(22):
        var angle := TAU * float(i) / 22.0
        var distance := 91.0 + float(i % 4) * 7.0
        var pos := Vector3(cos(angle) * distance, 7.0 + float(i % 3) * 2.0, sin(angle) * distance)
        var mountain := _sphere(self, 15.0 + float(i % 4) * 2.0, pos, mountain_colors[i % mountain_colors.size()], "MontanhaLowPoly")
        mountain.scale = Vector3(1.45, 1.35 + float(i % 3) * 0.22, 0.82)

    # Morros mais baixos preenchem o horizonte sem invadir o asfalto.
    for i in range(30):
        var angle := TAU * float(i) / 30.0 + 0.12
        var distance := 57.0 + float((i * 7) % 19)
        var pos := Vector3(cos(angle) * distance, 0.2, sin(angle) * distance)
        var hill := _sphere(self, 8.0 + float(i % 4) * 1.4, pos, Color(0.22, 0.43, 0.23) if i % 2 == 0 else Color(0.30, 0.51, 0.27), "MorroVerde")
        hill.scale = Vector3(1.55, 0.58 + float(i % 3) * 0.08, 1.18)

    # Árvores alinhadas às margens do circuito. A distância mínima evita
    # copas/troncos sobre o asfalto e mantém a leitura visual das curvas.
    for i in range(0, track_samples, 6):
        var t := TAU * float(i) / float(track_samples)
        var p := _track_point(t)
        var tangent := _track_tangent(t)
        var side := tangent.cross(Vector3.UP).normalized()
        var side_sign := -1.0 if (i / 6) % 2 == 0 else 1.0
        var offset := 12.0 + float((i * 3) % 5) * 0.9
        var tree_pos := p + side * side_sign * offset
        _make_tree(tree_pos, i + 11)
        if i % 12 == 0:
            var bush_pos := p + side * -side_sign * (offset + 2.5) + Vector3.UP * 0.45
            var bush := _sphere(self, 0.85 + float(i % 3) * 0.18, bush_pos, Color(0.16, 0.39, 0.17), "Arbusto")
            bush.scale = Vector3(1.35, 0.72, 1.0)

    # Pedras e tufos em grupos, sempre fora da faixa de rodagem.
    for i in range(0, track_samples, 11):
        var t := TAU * float(i) / float(track_samples)
        var p := _track_point(t)
        var tangent := _track_tangent(t)
        var side := tangent.cross(Vector3.UP).normalized()
        var sign_side := 1.0 if (i / 11) % 2 == 0 else -1.0
        var rock_pos := p + side * sign_side * (9.0 + float(i % 4)) + Vector3.UP * 0.48
        var rock_radius := 0.55 + float(i % 3) * 0.22
        var rock := _sphere(self, rock_radius, rock_pos, Color(0.30, 0.34, 0.33), "RochaMargem")
        rock.scale = Vector3(1.35, 0.72, 1.0)
        var rock_body := StaticBody3D.new()
        rock_body.name = "ColisaoRochaMargem"
        rock_body.position = rock_pos
        var rock_collision := CollisionShape3D.new()
        var rock_shape := SphereShape3D.new()
        rock_shape.radius = rock_radius * 0.9
        rock_collision.shape = rock_shape
        rock_body.add_child(rock_collision)
        add_child(rock_body)

    # Pequenos pontos de cor para quebrar grandes áreas verdes vazias.
    for i in range(84):
        var t := TAU * float(i) / 84.0
        var p := _track_point(t)
        var tangent := _track_tangent(t)
        var side := tangent.cross(Vector3.UP).normalized()
        var side_sign := -1.0 if i % 2 == 0 else 1.0
        var flower_pos := p + side * side_sign * (8.0 + float(i % 4) * 1.7) + Vector3.UP * 0.18
        var flower_color := Color(1.0, 0.72, 0.18) if i % 3 == 0 else Color(0.95, 0.88, 0.78)
        _sphere(self, 0.12, flower_pos, flower_color, "FlorMargem")

    # Portal de largada orientado conforme a tangente real do circuito.
    var start := _track_point(PI * 0.5)
    var tangent := _track_tangent(PI * 0.5)
    var side := tangent.cross(Vector3.UP).normalized()
    for sign_side in [-1.0, 1.0]:
        var post := _cylinder(self, 0.20, 5.4, start + side * sign_side * 6.7 + Vector3.UP * 2.7, Color(0.13, 0.17, 0.23), "PosteLargada")
    var banner := _box(self, Vector3(13.6, 0.75, 0.35), start + Vector3.UP * 5.0, Color(0.08, 0.12, 0.19), "PortalLargada")
    banner.look_at(banner.global_position + tangent, Vector3.UP)
    for i in range(14):
        var tile := _box(self, Vector3(0.85, 0.12, 0.38), start + side * (float(i) - 6.5) * 0.95 + Vector3.UP * 5.0, Color(0.96, 0.96, 0.91) if i % 2 == 0 else Color(0.08, 0.09, 0.11), "QuadriculadoPortal")
        tile.look_at(tile.global_position + tangent, Vector3.UP)

    # Mirante lateral e painéis de orientação.
    var lookout := _box(self, Vector3(8.0, 0.45, 4.0), Vector3(-54, 0.1, -14), Color(0.22, 0.25, 0.31), "MiranteBase")
    _box(self, Vector3(7.4, 2.3, 0.4), Vector3(-54, 1.45, -16), Color(0.12, 0.25, 0.38), "PainelMirante")
    for i in range(5):
        _box(self, Vector3(0.18, 1.0, 0.18), Vector3(-57 + i * 1.5, 1.2, -16), Color(0.96, 0.68, 0.15), "LuzMirante", 0.4, Color(0.8, 0.3, 0.05))

func _make_tree(p: Vector3, seed: int) -> void:
    var height := 2.0 + float(seed % 5) * 0.32
    var trunk_color := Color(0.34, 0.19, 0.10)
    _cylinder(self, 0.20, height, p + Vector3(0, height * 0.5, 0), trunk_color, "Tronco")
    var trunk_body := StaticBody3D.new()
    trunk_body.name = "ColisaoTronco"
    trunk_body.position = p + Vector3(0, height * 0.5, 0)
    var trunk_shape := CollisionShape3D.new()
    var trunk_cylinder := CylinderShape3D.new()
    trunk_cylinder.radius = 0.22
    trunk_cylinder.height = height
    trunk_shape.shape = trunk_cylinder
    trunk_body.add_child(trunk_shape)
    add_child(trunk_body)
    var palette := [Color(0.10, 0.34, 0.17), Color(0.15, 0.43, 0.20), Color(0.22, 0.50, 0.22), Color(0.12, 0.39, 0.27)]
    var crown := _sphere(self, 1.25 + float(seed % 3) * 0.2, p + Vector3(0, height + 0.55, 0), palette[seed % palette.size()], "Copa")
    crown.scale = Vector3(1.0, 0.88, 1.0)
    _sphere(self, 0.82, p + Vector3(-0.55, height + 0.28, 0.18), palette[(seed + 1) % palette.size()], "CopaLateral")
    if seed % 6 == 0:
        _cylinder(self, 0.12, 1.0, p + Vector3(0.8, height + 0.4, 0), Color(0.32, 0.22, 0.12), "Galho")

func _make_kart() -> void:
    kart = CharacterBody3D.new()
    kart.name = "Kart"
    var t := PI * 0.5
    var start := _track_point(t)
    kart.position = start + Vector3.UP * 0.85
    var tangent := _track_tangent(t)
    kart.rotation.y = atan2(-tangent.x, -tangent.z)
    kart.set_script(load("res://kart.gd"))
    add_child(kart)
    var visual_root := Node3D.new()
    visual_root.name = "ModeloVisual"
    visual_root.rotation_degrees = Vector3(-90, 180, 0)
    visual_root.position = Vector3(0, -0.43, 0)
    kart.add_child(visual_root)
    var kart_scene := load("res://assets/kart_livre_3d_ultra_suave.glb") as PackedScene
    if kart_scene:
        var model := kart_scene.instantiate()
        model.name = "KartModeloGLB"
        visual_root.add_child(model)
    else:
        push_warning("Não foi possível carregar o modelo GLB do kart")
    var collision := CollisionShape3D.new()
    collision.name = "ColisaoKart"
    var shape := BoxShape3D.new()
    shape.size = Vector3(1.85, 0.9, 2.45)
    collision.shape = shape
    collision.position = Vector3(0, 0.12, 0)
    kart.add_child(collision)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.name = "FollowCamera"
    camera.position = kart.global_position + Vector3(0, 5.2, 8.5).rotated(Vector3.UP, kart.rotation.y)
    camera.rotation_degrees = Vector3(-18, 0, 0)
    camera.current = true
    add_child(camera)

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    layer.name = "TouchHUD"
    add_child(layer)

    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(290, 104)
    panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.07, 0.09, 0.78)))
    layer.add_child(panel)
    var vbox := VBoxContainer.new()
    vbox.add_theme_constant_override("separation", 2)
    panel.add_child(vbox)

    speed_label = Label.new()
    speed_label.text = "VELOCIDADE  0 km/h"
    speed_label.add_theme_font_size_override("font_size", 21)
    vbox.add_child(speed_label)
    timer_label = Label.new()
    timer_label.text = "TEMPO  000.0"
    timer_label.add_theme_font_size_override("font_size", 17)
    vbox.add_child(timer_label)
    nitro_label = Label.new()
    nitro_label.text = "NITRO  PRONTO"
    nitro_label.add_theme_font_size_override("font_size", 16)
    vbox.add_child(nitro_label)

    var help := Label.new()
    help.text = "JOYSTICK: ARRASTE PARA VIRAR   •   SEGURE ACELERAR / FREIO / NITRO"
    help.position = Vector2(18, 128)
    help.add_theme_font_size_override("font_size", 13)
    layer.add_child(help)

    var touch_controls_script: Script = load("res://touch_controls.gd")
    var touch_controls: Control = touch_controls_script.new() as Control
    touch_controls.name = "HybridTouchControls"
    touch_controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(touch_controls)

func _panel_style(color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = 10
    style.corner_radius_top_right = 10
    style.corner_radius_bottom_left = 10
    style.corner_radius_bottom_right = 10
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 8
    style.content_margin_bottom = 8
    return style

func _physics_process(_delta: float) -> void:
    if is_instance_valid(kart) and is_instance_valid(camera):
        var offset := Vector3(0, 5.0, 8.5).rotated(Vector3.UP, kart.rotation.y)
        var target := kart.global_position + offset
        camera.global_position = camera.global_position.lerp(target, 0.085)
        camera.look_at(kart.global_position + Vector3(0, 0.55, 0), Vector3.UP)
