extends Control

# Controles táteis híbridos: joystick analógico à esquerda e botões à direita.
# Os eventos são tratados em _input para permitir multitoque real (direção + ação).

const JOYSTICK_RADIUS := 76.0
const KNOB_RADIUS := 29.0
const EDGE_MARGIN := 24.0

var _touch_regions: Dictionary = {}
var _joystick_touch: int = -999
var _joystick_axis: float = 0.0
var _mouse_active := false
var _pressed_actions: Dictionary = {}

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    process_mode = Node.PROCESS_MODE_ALWAYS
    queue_redraw()

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED:
        queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var touch := event as InputEventScreenTouch
        if touch.pressed:
            _begin_pointer(touch.index, touch.position)
        else:
            _end_pointer(touch.index)
    elif event is InputEventScreenDrag:
        var drag := event as InputEventScreenDrag
        _move_pointer(drag.index, drag.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        var mouse_button := event as InputEventMouseButton
        if mouse_button.pressed:
            _mouse_active = true
            _begin_pointer(-1, mouse_button.position)
        else:
            _mouse_active = false
            _end_pointer(-1)
    elif event is InputEventMouseMotion and _mouse_active:
        var mouse_motion := event as InputEventMouseMotion
        _move_pointer(-1, mouse_motion.position)

func _begin_pointer(pointer_id: int, position: Vector2) -> void:
    var center := _joystick_center()
    if _joystick_touch == -999 and position.distance_to(center) <= JOYSTICK_RADIUS * 1.45:
        _joystick_touch = pointer_id
        _update_joystick(position)
    else:
        var region := _button_region_at(position)
        if region != "":
            _touch_regions[pointer_id] = region
    _refresh_actions()
    queue_redraw()

func _move_pointer(pointer_id: int, position: Vector2) -> void:
    if pointer_id == _joystick_touch:
        _update_joystick(position)
        _refresh_actions()
        queue_redraw()

func _end_pointer(pointer_id: int) -> void:
    if pointer_id == _joystick_touch:
        _joystick_touch = -999
        _joystick_axis = 0.0
    _touch_regions.erase(pointer_id)
    _refresh_actions()
    queue_redraw()

func _update_joystick(position: Vector2) -> void:
    var displacement := position - _joystick_center()
    var normalized := clampf(displacement.x / JOYSTICK_RADIUS, -1.0, 1.0)
    if absf(normalized) < 0.13:
        normalized = 0.0
    _joystick_axis = normalized

func _joystick_center() -> Vector2:
    var view_size := get_viewport_rect().size
    return Vector2(EDGE_MARGIN + JOYSTICK_RADIUS + 12.0, view_size.y - EDGE_MARGIN - JOYSTICK_RADIUS - 12.0)

func _button_rect(action: String) -> Rect2:
    var view_size := get_viewport_rect().size
    var right := view_size.x - EDGE_MARGIN
    var bottom := view_size.y - EDGE_MARGIN
    if action == "accelerate":
        return Rect2(Vector2(right - 142.0, bottom - 142.0), Vector2(142.0, 142.0))
    if action == "brake":
        return Rect2(Vector2(right - 292.0, bottom - 86.0), Vector2(126.0, 76.0))
    if action == "nitro":
        return Rect2(Vector2(right - 292.0, bottom - 178.0), Vector2(126.0, 76.0))
    return Rect2()

func _button_region_at(position: Vector2) -> String:
    # Verificar primeiro o acelerador, que é o maior botão.
    for action in ["accelerate", "nitro", "brake"]:
        if _button_rect(action).has_point(position):
            return action
    return ""

func _refresh_actions() -> void:
    _set_action_strength("steer_left", maxf(-_joystick_axis, 0.0))
    _set_action_strength("steer_right", maxf(_joystick_axis, 0.0))
    for action in ["accelerate", "brake", "nitro"]:
        var is_down := false
        for region in _touch_regions.values():
            if region == action:
                is_down = true
                break
        _set_action_strength(action, 1.0 if is_down else 0.0)

func _set_action_strength(action: String, strength: float) -> void:
    if strength > 0.001:
        Input.action_press(action, clampf(strength, 0.0, 1.0))
        _pressed_actions[action] = true
    else:
        if _pressed_actions.has(action):
            Input.action_release(action)
            _pressed_actions.erase(action)

func _draw() -> void:
    var center := _joystick_center()
    var knob_center := center + Vector2(_joystick_axis * JOYSTICK_RADIUS, 0.0)
    draw_circle(center, JOYSTICK_RADIUS, Color(0.025, 0.055, 0.075, 0.48))
    draw_arc(center, JOYSTICK_RADIUS, 0.0, TAU, 64, Color(0.80, 0.91, 0.98, 0.72), 3.0, true)
    draw_circle(center, 5.0, Color(0.85, 0.93, 1.0, 0.48))
    draw_circle(knob_center, KNOB_RADIUS, Color(0.12, 0.62, 0.82, 0.94))
    draw_arc(knob_center, KNOB_RADIUS, 0.0, TAU, 48, Color(0.94, 0.98, 1.0, 0.95), 3.0, true)

    _draw_button("nitro", "NITRO", Color(0.05, 0.58, 0.78, 0.82), 16)
    _draw_button("brake", "FREIO", Color(0.78, 0.20, 0.18, 0.84), 17)
    _draw_button("accelerate", "ACELERAR", Color(0.12, 0.60, 0.28, 0.88), 17)

func _draw_button(action: String, caption: String, base_color: Color, font_size: int) -> void:
    var rect := _button_rect(action)
    var active := false
    for region in _touch_regions.values():
        if region == action:
            active = true
            break
    var fill := base_color.lightened(0.24) if active else base_color
    draw_rect(rect, fill, true)
    draw_rect(rect, Color(0.92, 0.98, 1.0, 0.9), false, 3.0)
    var font := ThemeDB.fallback_font
    var text_size := font.get_string_size(caption, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
    var text_position := Vector2(rect.position.x + (rect.size.x - text_size.x) * 0.5, rect.position.y + (rect.size.y + text_size.y * 0.55) * 0.5)
    draw_string(font, text_position, caption, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)

func _exit_tree() -> void:
    for action in _pressed_actions.keys():
        Input.action_release(action)
    _pressed_actions.clear()
